const InputComponent =( ) =>{
    return(
        <input/>
    )
}

export default InputComponent

