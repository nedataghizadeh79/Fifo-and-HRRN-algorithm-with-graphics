export function fifo(tasks) {
  tasks.sort((a, b) => a.cbt - b.cbt);

  tasks.sort((a, b) => a.arrival_time - b.arrival_time);

  const QUEUE = [];

  let time = 0;

  tasks.forEach((task) => {
    let item = {};

    time = Math.max(+time, +task.arrival_time);
    item.start_time = time;
    item.id = task.id;
    item.arrival_time = +task.arrival_time;
    item.cbt = +task.cbt;

    time += +task.cbt;
    item.end_time = time;

    QUEUE.push(item);
  });

  return QUEUE;
}

function getTasks(tasks, timeRange) {
  let taskRange = tasks.findIndex((task) => task.arrival_time > timeRange);

  if (taskRange < 0) {
    return tasks.length;
  }

  return taskRange + 1;
}

function getHighestRate(tasks, currentTime) {
  let index = 0;
  let rate = 0;

  tasks.forEach((task, idx) => {
    let taskRate = (currentTime - task.arrival_time) / task.cbt;
    if (taskRate > rate) {
      rate = taskRate;
      index = idx;
    } else if (taskRate === rate) {
      if (task.cbt < tasks[index].cbt) {
        rate = taskRate;
        index = idx;
      }
    }
  });

  return index;
}

export function hrrn(tasks) {
  tasks.sort((a, b) => a.arrival_time - b.arrival_time);

  const QUEUE = [];
  let time = +tasks[0].arrival_time;

  while (tasks.length > 0) {
    let item = {};
    item.start_time = time;

    let taskRange = getTasks(tasks, time);
    let highestRate = getHighestRate(tasks.slice(0, taskRange), time);

    item.id = tasks[highestRate].id;

    time += +tasks[highestRate].cbt;
    item.end_time = time;

    item.arrival_time = +tasks[highestRate].arrival_time;
    item.cbt = +tasks[highestRate].cbt;

    tasks.splice(highestRate, 1);

    QUEUE.push(item);
  }

  return QUEUE;
}

/*
my assumption:
task = {
    id
    arrival_time
    cbt
}
*/
