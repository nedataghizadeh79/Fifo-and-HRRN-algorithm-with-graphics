import { useState } from "react";
import { fifo, hrrn } from "../../utils/utils";
import backGround from "../../assets/hrrnBackgroun.png"


const HRRN = () => {
  const [mainInputValue, setMainInputValue] = useState("");
  const [inputValues, setInputValues] = useState({});
  const [tasks, setTasks] = useState([]);
  const [schedule, setSchedule] = useState([]);
  const [showResult, setShowResult] = useState(false);

  const initProblem = (event) => {
    setMainInputValue(+event.target.value);
    let initialTasks = [];
    for (let i = 0; i < event.target.value; i++) {
      initialTasks.push({ id: i, arrival_time: 0, cbt: 0 });
      let cbtId = "cbt-" + i;
      let arrivalId = "arrival-" + i;
      setInputValues((prev) => ({ ...prev, [cbtId]: "", [arrivalId]: "" }));
    }

    setTasks(initialTasks);
  };

  const onInputFill = (event) => {
    setInputValues((prev) => ({
      ...prev,
      [event.target.id]: +event.target.value,
    }));

    let [type, id] = event.target.id.split("-");

    setTasks((prev) => {
      let modifiedTasks = [...prev];

      modifiedTasks[id] =
        type === "cbt"
          ? { ...modifiedTasks[id], cbt: event.target.value }
          : { ...modifiedTasks[id], arrival_time: event.target.value };

      return modifiedTasks;
    });
  };

  const createInputs = (dataProp) => {
    const inputArray = [];
    for (let i = 0; i < mainInputValue; i++) {
      let id = "" + dataProp + "-" + i;
      inputArray.push(
        <input
          value={inputValues[id]}
          className="data-input"
          type="text"
          id={id}
          onChange={onInputFill}
          key={i}
        />
      );
    }
    return inputArray;
  };

  const renderResult = () => {
    const table = (
      <table>
        <tr>
          <th>task</th>
          <th>AT</th>
          <th>CBT</th>
          <th>FT</th>
          <th>RT</th>
          <th>WT</th>
        </tr>
        {schedule.map((task) => (
          <tr key={task.id}>
            <td>{task.id}</td>
            <td>{task.arrival_time}</td>
            <td>{task.cbt}</td>
            <td>{task.end_time}</td>
            <td>{task.end_time - task.arrival_time}</td>
            <td>{task.start_time - task.arrival_time}</td>
          </tr>
        ))}
      </table>
    );

    let timeSpan = schedule.reduce((prev, curr) => prev + curr.cbt, 0);

    let tape = (
      <div className="tape">
        {schedule.map((task, index) => (
          <div
            style={{
              width: `${(task.cbt / timeSpan) * 100}%`,
            }}
          >
            <span>{ task.start_time}</span>
            <span>P{task.id}</span>
            <span>{task.end_time}</span>
          </div>
        ))}
      </div>
    );

    return (
      <div className="result-container" dir="ltr">
        {table}
        {tape}
      </div>
    );
  };

  return (
    <section dir="rtl" className="makeRow" >
      {/*give AT*/}
      <section style={{ display: "flex", flexDirection: "row", gap: "5px" }}>
        <div>
          <label className="label" style={{paddingRight:"20px"}}>
            {" "}
            تعداد پردازه های خود را وارد کنید سپس در کادرهای ایجاد شده از سمت
            راست <span style={{ fontWeight: "bolder" }}>زمان ورود </span> هر
            پردازه را وارد کنید{" "}
          </label>
        </div>
        <input type="text" value={mainInputValue} onChange={initProblem} />
        <button onClick={createInputs} style={{color:"purple" , backgroundColor: '#ffd3dd', fontWeight:"bolder"  , border:"solid pink 5px", width:"110px" }}> درج اینپوت  </button>
      </section>
      <br />
      <div className="input-container">{createInputs("arrival")}</div>
      <br />

      <label className="label" style={{paddingRight:"20px"}}>
        {" "}
        در کادرهای ایجاد شده از سمت راست{" "}
        <span style={{ fontWeight: "bolder" }}>CBT</span> هر پردازه را وارد کنید
      </label>
      <div className="input-container">{createInputs("cbt")}</div>
      <br />

      <button style={{color:"purple" ,fontWeight:"bolder" , backgroundColor: '#ffd3dd' , border:"solid pink 5px", marginRight:"20px", width:"120px" }}
        onClick={() => {
          setSchedule(hrrn(tasks));
          setShowResult(true);
        }}
      >
        شروع
      </button>

      <section>
        {showResult && renderResult()  }
      </section>

      <section>
        <img alt='backGround' src={backGround} style={{width:"99%"  }} />
      </section>
    </section>

  );
};

export default HRRN;
