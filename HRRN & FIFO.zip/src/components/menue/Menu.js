import img_logo from "../../assets/login.png"
import backGround from "../../assets/backGround.png"
import "./Menu.css"
import {Link} from "react-router-dom";

const Menu = () => {


    return (
        <div className="all">
            <div dir="rtl" className="whole-part-div">

                <section className="whole-part-section">

                    <section className="right">
                        <div className="choosing-methods">
                            <label> لطفا روش مورد نظر خود را انتخاب کنید </label>
                            <br/>
                            <br/>
                            <section className="method-buttons">

                                <Link to="/HRRN">
                                    <button className="button"> HRRN</button>
                                </Link>

                                <br/>

                                <Link to="/FIFO">
                                    <button className="button"> FIFO</button>
                                </Link>

                            </section>
                        </div>
                    </section>

                    <section className="left">
                        <img src={img_logo} alt="operating system img" className="img-logo"/>
                    </section>

                </section>
            </div>
            <img src={backGround} className="back-ground"/>
        </div>
    )
}

export default Menu;