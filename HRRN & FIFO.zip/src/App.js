import "./App.css";
import Menu from "./components/menue/Menu";
import {BrowserRouter , Route} from "react-router-dom";
import FIFO from "./components/FIFO/FIFO";
import HRRN from "./components/HRRN/HRRN";


const App = () => {
    return (
        <BrowserRouter>
            <Route path="/" exact={true} component={Menu} />
            <Route path="/FIFO" component={FIFO} />
            <Route path="/HRRN" component={HRRN} />
        </BrowserRouter>

    )
}


export default App;